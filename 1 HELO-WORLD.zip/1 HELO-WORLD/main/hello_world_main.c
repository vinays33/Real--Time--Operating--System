#include <stdio.h>

void app_main()
{
    printf("Hello World!\n");
}